from kivy.app import App
import socket

HOST='192.168.0.8'
PORT=50007
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

class blinkApp(App):

    def turn_on(self):
        self.root.ids.state.text = 'Set to On!'
        s.send("Turn on!\r")
        data= s.recv(1024)
        self.root.ids.log.text = data

    def turn_off(self):
        self.root.ids.state.text = 'Set to Off'
        s.send("Turn off!\r")
        data= s.recv(1024)
        self.root.ids.log.text = data
 
    def state(self):
       s.send("Get state!\r")
       data= s.recv(1024)
       self.root.ids.state.text = data
       self.root.ids.log.text = data

if __name__ == '__main__':
    blinkApp().run()
